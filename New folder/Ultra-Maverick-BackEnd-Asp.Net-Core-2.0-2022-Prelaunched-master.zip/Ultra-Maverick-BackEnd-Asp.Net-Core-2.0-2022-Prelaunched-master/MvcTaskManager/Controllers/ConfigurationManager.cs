﻿namespace MvcTaskManager.Controllers
{
  internal class ConfigurationManager
  {
  }
}